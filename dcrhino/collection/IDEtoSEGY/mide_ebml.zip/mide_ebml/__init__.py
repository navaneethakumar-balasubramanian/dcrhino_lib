#!
'''
Package for reading and analyzing Mide Instrumentation Data Exchange (MIDE)
files.
'''

__author__ = "David Randall Stokes"
__copyright__ = u"Copyright (c) 2015 Mid\xe9 Technology"

__maintainer__ = "David Randall Stokes"
__email__ = "dstokes@mide.com"

__version__ = (1,3,0)
__status__ = "Production"

# import dataset
# import importer
# import parser